
import React, { useState } from "react";
import PizZip from "pizzip";
import { DOMParser } from "@xmldom/xmldom";

function str2xml(str:any) {
  if (str.charCodeAt(0) === 65279) {
    // BOM sequence
    str = str.substr(1);
  }
  return new DOMParser().parseFromString(str, "text/xml");
}

// Get paragraphs as javascript array
function getParagraphs(content:any) {
  const zip = new PizZip(content);
  const xml = str2xml(zip.files["word/document.xml"].asText());
  const paragraphsXml = xml.getElementsByTagName("w:p");
  const paragraphs = [];

  for (let i = 0, len = paragraphsXml.length; i < len; i++) {
    let fullText = "";
    const textsXml = paragraphsXml[i].getElementsByTagName("w:t");
    for (let j = 0, len2 = textsXml.length; j < len2; j++) {
      const textXml = textsXml[j];
      if (textXml.childNodes) {
        fullText += textXml.childNodes[0].nodeValue;
      }
    }
    if (fullText) {
      paragraphs.push(fullText);
    }
  }
  return paragraphs;
}

const Test = () => {
  const [paragraphs, setParagraphs] =  useState<String[]>([]);

  const onFileUpload = (event:any) => {
    const reader = new FileReader();
    const file = event.target.files?.[0];
    
    const fileList = file?.name.split('.');
    console.log(fileList[fileList-1])

    reader.onload = (e) => {
      const content = e.target?.result as string; //e.target?.result as string;
      const paragraphs = getParagraphs(content);
      setParagraphs(paragraphs);
      console.log(paragraphs);
    };
    reader.onerror = (err) => console.error(err);

    reader.readAsArrayBuffer(file);
  };

  return (
    <>
  <input type="file" onChange={onFileUpload} name="docx-reader" />
  <p>{paragraphs}</p>
  </>
  );
  
};

export default Test;
