import React, { useState } from 'react';
import './FileUpload.css';
import { delay, isEmpty } from 'lodash';


interface ModalProps {
  isOpen: boolean;
   onClose: () => void;
   stopGenerating:()=> void;
   onSend: (question: string, id?: string) => void;
   disabled: boolean;
   placeholder?: string;
   clearOnSend?: boolean;
   conversationId?: string;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose,stopGenerating,onSend, disabled, placeholder, clearOnSend, conversationId  }) => {
  if (!isOpen) {
    return null;
  }
  const [isDisplayVisible,SetisDisplayVisible] = useState<boolean>(false);
  const [fileText,SetFileText] = useState<string>("");
  let Textarr : string[] = [];
  const uploadFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    
    const file = event.target.files?.[0];
    
    if (file) {
       
        const reader = new FileReader();
        reader.onload =  (e) => {
            const fileContent = e.target?.result as string;
            const charCount = fileContent.length;
            console.log(`Character count: ${charCount}`);
           SetFileText(fileContent);
         
            let text = fileContent;
            if(charCount>0){
              while(text.length!=0){
                 let res = text.substring(0,4000);
                 Textarr.push(res);
                 text = text.slice(4000);
              }
              Textarr.join()
            }
            Textarr.push('<End>')
            Textarr.unshift('<Start>')
            console.log(Textarr);
             Textarr.map( (element,index)=>{
              if (Textarr.length>index ){
              e.preventDefault();
              sendQuestion(element);
              new Promise(f => setTimeout(f, 9000));
              console.log('inCOnverstation')
            //  alert('Inside')
              
              }
              else{
                e.preventDefault();
                 sendQuestion(element);
                 SetisDisplayVisible(true);
                 alert('Outside')
              }
            })
        };
        reader.readAsText(file);
    }
};
const sendQuestion =  (resData : string) => {
  
  if (disabled || !resData.trim()) {
      return;
  }

  if(conversationId){
     
      onSend(resData, conversationId);
  }else{
    
      onSend(resData);
  }

};
  return (
    <>
    <div className="fileAttachment-container">
      <div className="file-attachment-body">
        <div className="file-header">
          <h2>File Attachment</h2>
        </div>
        <div className="fileinputContainer">
        <input type="file" id="myfile" name="myfile"  onChange={uploadFile} /><br></br>
        </div>
        <div className="file-text-MainContainer">
        <div className="file-textbodyContainer">
          <div className="file-textScreen">
            <p>{fileText}</p>
            
          </div>
          <div className="buttonContainer">
        <button
        className="mt-4 bg-red-500 hover:bg-red-700 text-black py-2 px-4 rounded"
        onClick={onClose}
        // style={{ display: isDisplayVisible ? 'none' : 'block' }}
      >
        Close Modal
      </button>
        </div>

        </div>
        </div>
        
      </div>
    </div>
  </>
    
  );
};  

export default Modal;