import { ReactDOM, useState } from "react";

import './SkillAssistStyle.css';

interface MyChildProps {
    isDisplayVisible: boolean;
    onSend: (question: string, id?: string) => void;
    disabled: boolean;
    placeholder?: string;
    clearOnSend?: boolean;
    conversationId?: string;
}

const SkillAssist: React.FC<MyChildProps> = ({ isDisplayVisible,onSend, disabled, placeholder, clearOnSend, conversationId  }) => {
   

  



    const skillName = [
        "Agile",
        "Application Development",
        "Project Management",
        "Applications Support and Enhancement",
        "Business Intelligence",
        "Business Model Innovation",
        "Business Needs Analysis",
        "Business Risk Management",
        "Change Management"]

       
    const [skillLevels, setSkillLevels] = useState<{ [key: string]: number }>({
        "Agile": 0,
        "Application": 0,
        "Project Management": 0,
        "Applications Support and Enhancement": 0,
        "Business Intelligence": 0,
        "Business Model Innovation": 0,
        "Business Needs Analysis": 0,
        "Business Risk Management": 0,
        "Change Management": 0
    });

    const handleSliderChange = (skill: string, value: number) => {
        setSkillLevels((prevLevels) => ({ ...prevLevels, [skill]: value }));
    };


    const sendQuestion = () => {
        const jsonString = "This is my skillset with ratings : "+JSON.stringify(skillLevels) ;
        if (disabled || !jsonString.trim()) {
            return;
        }

        if(conversationId){
           
            onSend(jsonString, conversationId);
        }else{
          
            onSend(jsonString);
        }

    };

    var str: string = "I know the following skills :";



    const ClearInputGiven = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        
        setSkillLevels({
            "Agile": 0,
            "Application": 0,
            "Project Management": 0,
            "Applications Support and Enhancement": 0,
            "Business Intelligence": 0,
            "Business Model Innovation": 0,
            "Business Needs Analysis": 0,
            "Business Risk Management": 0,
            "Change Management": 0
        });
        isDisplayVisible = !isDisplayVisible;
        alert("skill cleared successfully");

    }





    return (
        <>
            <div className="parent-skill-container" style={{ display: isDisplayVisible ? 'none' : 'block' }}>

               



                <div className="Skill-Container">
                    {
                        Object.keys(skillLevels).map((skill) => (<>
                            <div className="Skill_Divison">
                                <div className="skill-name">
                                    <label htmlFor="customRange2" className="skill-name-label">{skill}</label>
                                </div>
                                <div className="skill-tracker" key={skill}>
                                    <input type="range" className="form-range" min="0" max="10" defaultValue={0} onChange={(e) => handleSliderChange(skill, Number(e.target.value))} value={skillLevels[skill]} />
                                    <label>{skillLevels[skill]}</label>
                                </div>
                            </div>
                        </>))
                    }


                </div>


                <div className="choose-btn">
                    <button className="btn btn-primary" type="button" onClick={sendQuestion}> Add </button>
                    <button className="btn btn-primary" type="button" onClick={ClearInputGiven}>Clear</button>
                </div>





            </div>

        </>
    );

};

export default SkillAssist;

